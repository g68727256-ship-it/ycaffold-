package br.com.ysharkx7.scaffold;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.Vec3;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

/** Implementacao experimental para mundos proprios/testes autorizados. */
public final class ScaffoldLogic {
    private ScaffoldLogic() {}

    public static void tick(Minecraft mc) {
        EntityPlayerSP player = mc.thePlayer;
        WorldClient world = mc.theWorld;
        if (player.isSpectator() || player.isSneaking() || YSharkScaffold.placeCooldown > 0) return;

        int slot = findBlockSlot(player);
        if (slot < 0) return;

        BlockPos target = new BlockPos(player.posX, player.getEntityBoundingBox().minY - 1.0D, player.posZ);
        if (world.getBlockState(target).getBlock().getMaterial() != Material.air) return;

        BlockPos support = null;
        EnumFacing hitSide = null;
        for (EnumFacing direction : EnumFacing.values()) {
            BlockPos candidate = target.offset(direction);
            Block block = world.getBlockState(candidate).getBlock();
            if (block.getMaterial().isSolid() && block.isFullBlock()) {
                support = candidate;
                hitSide = direction.getOpposite();
                break;
            }
        }
        if (support == null) return;

        int oldSlot = player.inventory.currentItem;
        player.inventory.currentItem = slot;
        ItemStack stack = player.getHeldItem();
        if (stack != null && stack.getItem() instanceof ItemBlock) {
            Vec3 hit = new Vec3(support.getX() + 0.5D, support.getY() + 0.5D, support.getZ() + 0.5D);
            boolean success = mc.playerController.onPlayerRightClick(player, world, stack, support, hitSide, hit);
            if (success) {
                player.swingItem();
                YSharkScaffold.blocksPlaced++;
                YSharkScaffold.placeCooldown = Math.max(1, YSharkScaffold.delayTicks);
            }
        }
        player.inventory.currentItem = oldSlot;
    }

    private static int findBlockSlot(EntityPlayerSP player) {
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.inventory.getStackInSlot(i);
            if (stack != null && stack.getItem() instanceof ItemBlock) return i;
        }
        return -1;
    }
}
