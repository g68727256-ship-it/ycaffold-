package br.com.ysharkx7.scaffold;

import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import java.util.Collections;
import java.util.List;

public class ScaffoldCommand extends CommandBase {
    public String getCommandName() { return "yscaffold"; }
    public String getCommandUsage(ICommandSender sender) { return "/yscaffold <on|off|status|delay 1-10>"; }

    public void processCommand(ICommandSender sender, String[] args) {
        if (args.length == 0) { msg(sender, getCommandUsage(sender)); return; }
        String sub = args[0].toLowerCase();
        if ("on".equals(sub)) {
            YSharkScaffold.enabled = true; msg(sender, "Scaffold ativado.");
        } else if ("off".equals(sub)) {
            YSharkScaffold.enabled = false; msg(sender, "Scaffold desativado.");
        } else if ("eagle".equals(sub)) {
            YSharkScaffold.eagle = !YSharkScaffold.eagle; msg(sender, "Eagle: " + YSharkScaffold.eagle + " (logica ainda nao implementada).");
        } else if ("status".equals(sub)) {
            msg(sender, "Ativo: " + YSharkScaffold.enabled + " | Blocos colocados: " + YSharkScaffold.blocksPlaced);
        } else if ("delay".equals(sub) && args.length > 1) {
            try {
                int n = Integer.parseInt(args[1]);
                if (n < 1 || n > 10) throw new NumberFormatException();
                YSharkScaffold.delayTicks = n; msg(sender, "Delay: " + n + " ticks.");
            } catch (NumberFormatException e) { msg(sender, "Use /yscaffold delay 1-10."); }
        } else msg(sender, getCommandUsage(sender));
    }
    private void msg(ICommandSender sender, String s) { sender.addChatMessage(new ChatComponentText("[YSHARKX7] " + s)); }
    public int getRequiredPermissionLevel() { return 0; }
    public List<String> addTabCompletionOptions(ICommandSender sender, String[] args, BlockPos pos) {
        if (args.length == 1) return getListOfStringsMatchingLastWord(args, "on", "off", "eagle", "status", "delay");
        return Collections.emptyList();
    }
}
