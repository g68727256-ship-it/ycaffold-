package br.com.ysharkx7.scaffold;

import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

@Mod(modid = YSharkScaffold.MODID, name = YSharkScaffold.NAME, version = YSharkScaffold.VERSION, acceptedMinecraftVersions = "[1.8.9]")
public class YSharkScaffold {
    public static final String MODID = "ysharkx7scaffold";
    public static final String NAME = "YSHARKX7 Scaffold";
    public static final String VERSION = "1.0.0";
    public static KeyBinding toggleKey, eagleKey;
    public static boolean enabled = false, eagle = false;
    public static int blocksPlaced = 0, delayTicks = 2, placeCooldown = 0;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        toggleKey = new KeyBinding("YSHARKX7 Scaffold: Ativar/Desativar", Keyboard.KEY_NONE, "YSHARKX7");
        eagleKey = new KeyBinding("YSHARKX7 Scaffold: Eagle", Keyboard.KEY_NONE, "YSHARKX7");
        ClientRegistry.registerKeyBinding(toggleKey);
        ClientRegistry.registerKeyBinding(eagleKey);
        MinecraftForge.EVENT_BUS.register(this);
        ClientCommandHandler.instance.registerCommand(new ScaffoldCommand());
    }

    @SubscribeEvent
    public void onKey(InputEvent.KeyInputEvent event) {
        if (toggleKey.isPressed()) enabled = !enabled;
        if (eagleKey.isPressed()) eagle = !eagle;
    }

    @SubscribeEvent
    public void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.thePlayer == null || mc.theWorld == null) return;
        if (placeCooldown > 0) placeCooldown--;
        if (enabled) ScaffoldLogic.tick(mc);
    }
}
